// --- products.js ---
// IzzyExpress Product Data & Dynamic Pricing Engine

// Real-world high demand products (Amazon/eBay 2026 Trends)
const products = [
    { id: 1, name: "Stanley Quencher H2.0", price: 45.00, category: "Home & Kitchen", image: "https://images.unsplash.com/photo-1614210355449-74e1d6701cf2?auto=format&fit=crop&w=600&q=80", desc: "40 oz Stainless Steel Vacuum Insulated Tumbler.", featured: true, trending: true, rating: 4.8 },
    { id: 2, name: "Retro Digital Camera Y2K", price: 125.00, category: "Electronics", image: "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?auto=format&fit=crop&w=600&q=80", desc: "Refurbished vintage point-and-shoot camera.", featured: true, trending: true, rating: 4.5 },
    { id: 3, name: "Mighty Patch Original", price: 12.99, category: "Beauty", image: "https://images.unsplash.com/photo-1629198728070-7b6fb9552140?auto=format&fit=crop&w=600&q=80", desc: "Hydrocolloid acne pimple patch for spot treatment.", featured: false, trending: true, rating: 4.7 },
    { id: 4, name: "Sleep Earbuds Gen 2", price: 140.00, category: "Electronics", image: "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=600&q=80", desc: "Noise-masking sleep earbuds for side sleepers.", featured: true, trending: true, rating: 4.9 },
    { id: 5, name: "Ergonomic Office Chair", price: 199.00, category: "Home & Kitchen", image: "https://images.unsplash.com/photo-1505843490538-5133c6c7d0e1?auto=format&fit=crop&w=600&q=80", desc: "Mesh desk chair with lumbar support and 3D armrests.", featured: true, trending: false, rating: 4.6 },
    { id: 6, name: "Organic Glow Serum", price: 35.00, category: "Beauty", image: "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&w=600&q=80", desc: "Vitamin C face serum for brightening and anti-aging.", featured: false, trending: true, rating: 4.4 },
    { id: 7, name: "Vintage Wash Denim Jacket", price: 89.99, category: "Fashion", image: "https://images.unsplash.com/photo-1551028719-01c1eb562a11?auto=format&fit=crop&w=600&q=80", desc: "Classic oversized denim jacket for all seasons.", featured: false, trending: false, rating: 4.3 },
    { id: 8, name: "Cloud Running Sneakers", price: 130.00, category: "Fashion", image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=600&q=80", desc: "Ultra-lightweight and breathable athletic shoes.", featured: false, trending: true, rating: 4.8 },
    { id: 9, name: "Candle Warmer Lamp", price: 45.00, category: "Home & Kitchen", image: "https://images.unsplash.com/photo-1603006905003-be475563bc59?auto=format&fit=crop&w=600&q=80", desc: "Dimmable candle melting lamp for safe fragrance.", featured: false, trending: true, rating: 4.9 },
    { id: 10, name: "Premium Protein Powder", price: 35.00, category: "Health", image: "https://images.unsplash.com/photo-1579722820308-d74e571900a9?auto=format&fit=crop&w=600&q=80", desc: "Grass-fed whey protein isolate, vanilla bean.", featured: false, trending: false, rating: 4.2 },
    { id: 11, name: "Smart Surge Protector", price: 29.99, category: "Electronics", image: "https://images.unsplash.com/photo-1558089687-f282ffcbc126?auto=format&fit=crop&w=600&q=80", desc: "Wi-Fi smart power strip compatible with Alexa.", featured: false, trending: false, rating: 4.1 },
    { id: 12, name: "Designer Crossbody Bag", price: 350.00, category: "Fashion", image: "https://images.unsplash.com/photo-1584916201218-f4242ceb4809?auto=format&fit=crop&w=600&q=80", desc: "Authentic pre-loved designer leather handbag.", featured: true, trending: false, rating: 4.8 },
];

const categories = [
    { name: "Electronics", icon: "ph-desktop" },
    { name: "Fashion", icon: "ph-t-shirt" },
    { name: "Home & Kitchen", icon: "ph-house" },
    { name: "Beauty", icon: "ph-sparkle" },
    { name: "Health", icon: "ph-heartbeat" }
];

// --- Dynamic Pricing Engine ---
// Simulates fetching real-time market data to adjust prices subtly.
function initDynamicPricing() {
    // Every 15 seconds, randomly fluctuate prices of trending items to simulate live market demand.
    setInterval(() => {
        let pricesChanged = false;
        products.forEach(p => {
            if (p.trending && Math.random() > 0.7) { // 30% chance to fluctuate
                // Fluctuate between -2% and +3%
                const changePercent = (Math.random() * 5 - 2) / 100;
                let newPrice = p.price * (1 + changePercent);
                p.price = Math.round(newPrice * 100) / 100;
                pricesChanged = true;
            }
        });
        
        // If prices changed and we are on a page that displays products, re-render
        if (pricesChanged) {
            if (window.renderShop && document.getElementById('shop-grid')) {
                renderShop(false); // Render without losing scroll position
            }
            if (window.renderHome && document.getElementById('trending-products')) {
                renderHome();
            }
            if (window.renderCart && document.getElementById('cart-items-list')) {
                renderCart(); // Update cart totals with new prices
                updateCartBadge();
            }
        }
    }, 15000);
}

// Start pricing engine
initDynamicPricing();

const formatPrice = (price) => `$${price.toFixed(2)}`;
