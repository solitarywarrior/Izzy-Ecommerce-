// --- cart.js ---
// Logic for handling the shopping cart

let cart = JSON.parse(localStorage.getItem('izzy_cart')) || [];

function saveCart() {
    localStorage.setItem('izzy_cart', JSON.stringify(cart));
    updateCartBadge();
}

function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    if (!product) return;

    const existing = cart.find(item => item.id === productId);
    if (existing) {
        existing.quantity += 1;
    } else {
        cart.push({ id: product.id, quantity: 1 });
    }
    
    saveCart();
    if (window.showToast) showToast(`Added ${product.name} to cart`);
}

function removeFromCart(productId) {
    cart = cart.filter(item => item.id !== productId);
    saveCart();
    if (window.renderCart) renderCart();
}

function updateQuantity(productId, delta) {
    const item = cart.find(i => i.id === productId);
    if (item) {
        item.quantity += delta;
        if (item.quantity <= 0) {
            removeFromCart(productId);
        } else {
            saveCart();
            if (window.renderCart) renderCart();
        }
    }
}

function updateCartBadge() {
    const badge = document.getElementById('cart-badge');
    if (!badge) return;
    
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    if (totalItems > 0) {
        badge.textContent = totalItems;
        badge.classList.remove('hidden');
    } else {
        badge.classList.add('hidden');
    }
}

// Ensure badge is updated on page load
document.addEventListener('DOMContentLoaded', updateCartBadge);
