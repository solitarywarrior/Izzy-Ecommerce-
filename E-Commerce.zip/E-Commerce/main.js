// --- main.js ---
// Global utilities and UI logic for IzzyExpress

// --- NOTIFICATIONS ---
function showToast(message) {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        document.body.appendChild(container);
    }
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = `<i class="ph-fill ph-check-circle text-xl"></i> <span>${message}</span>`;
    container.appendChild(toast);
    setTimeout(() => { toast.remove(); }, 3000);
}

// --- THEME ---
function toggleTheme() {
    const html = document.documentElement;
    html.classList.toggle('dark');
    const isDark = html.classList.contains('dark');
    const icon = document.getElementById('theme-icon');
    if(icon) {
        icon.className = isDark ? 'ph ph-sun text-xl' : 'ph ph-moon text-xl';
    }
    localStorage.setItem('theme', isDark ? 'dark' : 'light');
}

function initTheme() {
    const saved = localStorage.getItem('theme');
    if (saved === 'light') {
        document.documentElement.classList.remove('dark');
    } else {
        // default to dark
        document.documentElement.classList.add('dark');
    }
}

// --- SEARCH ---
function handleSearch(e, value) {
    if (e.key === 'Enter') {
        window.location.href = `shop.html?search=${encodeURIComponent(value)}`;
    }
}

// --- DYNAMIC HEADER AND FOOTER INJECTION ---
function renderHeaderAndFooter() {
    const headerHTML = `
    <header class="sticky top-0 z-50 bg-white/80 dark:bg-darkBg/80 backdrop-blur-md border-b border-gray-200 dark:border-gray-800 transition-colors duration-300">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                <!-- Logo -->
                <a href="index.html" class="flex-shrink-0 cursor-pointer flex items-center gap-2">
                    <i class="ph-fill ph-shopping-bag text-3xl text-brand-500"></i>
                    <span class="font-bold text-2xl tracking-tight text-gray-900 dark:text-white">Izzy<span class="text-brand-500">Express</span></span>
                </a>

                <!-- Desktop Menu -->
                <nav class="hidden md:flex items-center gap-8 font-medium">
                    <a href="index.html" class="nav-link hover:text-brand-500 transition-colors">Home</a>
                    <a href="shop.html" class="nav-link hover:text-brand-500 transition-colors">Shop</a>
                    <a href="about us.html" class="nav-link hover:text-brand-500 transition-colors">About Us</a>
                </nav>

                <!-- Actions -->
                <div class="flex items-center gap-4">
                    <!-- Search Bar (Desktop) -->
                    <div class="hidden lg:flex relative">
                        <input type="text" id="desktop-search" placeholder="Search products..." class="bg-gray-100 dark:bg-gray-800 text-sm rounded-full pl-10 pr-4 py-2 focus:outline-none focus:ring-2 focus:ring-brand-500 dark:text-white transition-colors" onkeypress="handleSearch(event, this.value)">
                        <i class="ph ph-magnifying-glass absolute left-3 top-2.5 text-gray-500"></i>
                    </div>

                    <!-- Theme Toggle -->
                    <button onclick="toggleTheme()" class="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-800 transition-colors" aria-label="Toggle Theme">
                        <i id="theme-icon" class="ph ph-moon text-xl"></i>
                    </button>

                    <!-- User Login -->
                    <a href="login.html" class="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-800 transition-colors" aria-label="Login">
                        <i class="ph ph-user text-xl"></i>
                    </a>

                    <!-- Cart -->
                    <a href="cart.html" class="relative p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-800 transition-colors">
                        <i class="ph ph-shopping-cart text-xl"></i>
                        <span id="cart-badge" class="absolute top-0 right-0 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-white transform translate-x-1/4 -translate-y-1/4 bg-brand-500 rounded-full hidden">0</span>
                    </a>

                    <!-- Mobile Menu Button -->
                    <button id="mobile-menu-btn" class="md:hidden p-2 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-800 transition-colors">
                        <i class="ph ph-list text-2xl"></i>
                    </button>
                </div>
            </div>
        </div>

        <!-- Mobile Menu -->
        <div id="mobile-menu" class="hidden md:hidden bg-white dark:bg-darkCard border-b border-gray-200 dark:border-gray-800 pb-4 px-4 space-y-2 absolute w-full left-0 shadow-lg">
            <div class="relative mt-2 mb-4">
                <input type="text" id="mobile-search" placeholder="Search products..." class="w-full bg-gray-100 dark:bg-gray-800 text-sm rounded-full pl-10 pr-4 py-2 focus:outline-none focus:ring-2 focus:ring-brand-500 dark:text-white" onkeypress="handleSearch(event, this.value)">
                <i class="ph ph-magnifying-glass absolute left-3 top-2.5 text-gray-500"></i>
            </div>
            <a href="index.html" class="block py-2 text-base font-medium hover:text-brand-500">Home</a>
            <a href="shop.html" class="block py-2 text-base font-medium hover:text-brand-500">Shop</a>
            <a href="cart.html" class="block py-2 text-base font-medium hover:text-brand-500">Cart</a>
            <a href="about us.html" class="block py-2 text-base font-medium hover:text-brand-500">About Us</a>
            <a href="login.html" class="block py-2 text-base font-medium hover:text-brand-500">Login</a>
        </div>
    </header>
    `;

    const footerHTML = `
    <footer class="bg-white dark:bg-darkCard border-t border-gray-200 dark:border-gray-800 pt-16 pb-8 transition-colors duration-300 mt-auto">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
                <div class="col-span-1 md:col-span-1">
                    <div class="flex items-center gap-2 mb-4">
                        <i class="ph-fill ph-shopping-bag text-2xl text-brand-500"></i>
                        <span class="font-bold text-xl tracking-tight text-gray-900 dark:text-white">Izzy<span class="text-brand-500">Express</span></span>
                    </div>
                    <p class="text-gray-500 text-sm mb-4">Your premium destination for the best products online. Fast, secure, and reliable.</p>
                    <div class="flex gap-4">
                        <a href="#" class="text-gray-400 hover:text-brand-500 text-xl transition-colors"><i class="ph-fill ph-twitter-logo"></i></a>
                        <a href="#" class="text-gray-400 hover:text-brand-500 text-xl transition-colors"><i class="ph-fill ph-instagram-logo"></i></a>
                        <a href="#" class="text-gray-400 hover:text-brand-500 text-xl transition-colors"><i class="ph-fill ph-facebook-logo"></i></a>
                    </div>
                </div>
                
                <div>
                    <h4 class="font-bold mb-4 text-gray-900 dark:text-white">Shop</h4>
                    <ul class="space-y-2 text-sm text-gray-500">
                        <li><a href="shop.html?category=Electronics" class="hover:text-brand-500 transition-colors">Electronics</a></li>
                        <li><a href="shop.html?category=Fashion" class="hover:text-brand-500 transition-colors">Fashion</a></li>
                        <li><a href="shop.html?category=Home%20&%20Kitchen" class="hover:text-brand-500 transition-colors">Home & Kitchen</a></li>
                        <li><a href="shop.html" class="hover:text-brand-500 transition-colors">New Arrivals</a></li>
                    </ul>
                </div>
                
                <div>
                    <h4 class="font-bold mb-4 text-gray-900 dark:text-white">Support</h4>
                    <ul class="space-y-2 text-sm text-gray-500">
                        <li><a href="about us.html" class="hover:text-brand-500 transition-colors">About Us</a></li>
                        <li><a href="track.html" class="hover:text-brand-500 transition-colors">Track Order</a></li>
                        <li><a href="returns.html" class="hover:text-brand-500 transition-colors">Returns & Refunds</a></li>
                        <li><a href="contact.html" class="hover:text-brand-500 transition-colors">Contact Us</a></li>
                    </ul>
                </div>

                <div>
                    <h4 class="font-bold mb-4 text-gray-900 dark:text-white">Legal</h4>
                    <ul class="space-y-2 text-sm text-gray-500">
                        <li><a href="terms.html" class="hover:text-brand-500 transition-colors">Terms of Service</a></li>
                        <li><a href="privacy.html" class="hover:text-brand-500 transition-colors">Privacy Policy</a></li>
                    </ul>
                </div>
            </div>
            <div class="border-t border-gray-200 dark:border-gray-800 pt-8 flex flex-col md:flex-row items-center justify-between text-sm text-gray-500">
                <p>&copy; 2026 IzzyExpress. All rights reserved.</p>
                <div class="flex items-center gap-2 mt-4 md:mt-0">
                    <i class="ph-fill ph-stripe-logo text-2xl"></i>
                    <i class="ph-fill ph-paypal-logo text-2xl"></i>
                </div>
            </div>
        </div>
    </footer>
    `;

    const headerEl = document.getElementById('shared-header');
    const footerEl = document.getElementById('shared-footer');
    
    if(headerEl) headerEl.innerHTML = headerHTML;
    if(footerEl) footerEl.innerHTML = footerHTML;

    // Attach mobile menu logic
    const mobileMenuBtn = document.getElementById('mobile-menu-btn');
    if(mobileMenuBtn) {
        mobileMenuBtn.addEventListener('click', () => {
            const menu = document.getElementById('mobile-menu');
            if(menu) menu.classList.toggle('hidden');
        });
    }

    // Set theme icon based on current state
    const isDark = document.documentElement.classList.contains('dark');
    const icon = document.getElementById('theme-icon');
    if (icon) {
        icon.className = isDark ? 'ph ph-sun text-xl' : 'ph ph-moon text-xl';
    }
}

// Run Initialization
document.addEventListener('DOMContentLoaded', () => {
    initTheme();
    renderHeaderAndFooter();
    if(window.updateCartBadge) updateCartBadge();
});
