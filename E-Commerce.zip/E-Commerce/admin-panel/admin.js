// Logic for Admin Portal

// Logic for Admin Portal

// --- API CONFIGURATION ---
// Option 1: Modern Node.js Backend (Vercel/Render)
// const API_BASE = 'http://localhost:5000/api';

// Option 2: Local XAMPP PHP Backend
// To use PHP, make sure this folder is inside C:\xampp\htdocs\E-Commerce
const API_BASE = 'http://localhost/E-Commerce/backend(xampp)';
// -------------------------

// Handle Login
const loginForm = document.getElementById('admin-login-form');
if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const errorMsg = document.getElementById('error-msg');

        try {
            // Note: Since you don't have Node.js running yet, we will simulate the backend response for demonstration.
            // In production, uncomment the fetch call below.
            
            // --- REAL BACKEND FETCH CODE ---
            // Uncomment this when running Node.js or PHP
            /*
            // Determine auth endpoint based on which API we are using
            const endpoint = API_BASE.includes('xampp') ? `${API_BASE}/auth.php?action=login` : `${API_BASE}/auth/login`;

            const res = await fetch(endpoint, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });
            const data = await res.json();
            
            if (!res.ok) throw new Error(data.error);
            if (data.user.role !== 'admin') throw new Error('Unauthorized');
            
            localStorage.setItem('admin_token', data.token);
            localStorage.setItem('admin_email', data.user.email);
            window.location.href = 'dashboard.html';
            */

            // SIMULATION (for when no backend is running at all)
            if (email === 'admin@mail.com' && password === '123456') {
                localStorage.setItem('admin_token', 'mock_jwt_token_for_admin_123');
                localStorage.setItem('admin_email', email);
                window.location.href = 'dashboard.html';
            } else {
                throw new Error('Invalid credentials');
            }

        } catch (err) {
            errorMsg.textContent = err.message;
            errorMsg.classList.remove('hidden');
        }
    });
}

// Authentication Check for Dashboard
function checkAdminAuth() {
    const token = localStorage.getItem('admin_token');
    if (!token) {
        window.location.href = 'index.html';
        return;
    }

    const emailDisplay = document.getElementById('admin-email');
    if (emailDisplay) {
        emailDisplay.textContent = localStorage.getItem('admin_email');
    }

    // Here you would normally fetch products from the backend:
    // fetchProducts();
}

function logoutAdmin() {
    localStorage.removeItem('admin_token');
    localStorage.removeItem('admin_email');
    window.location.href = 'index.html';
}

// Example function to fetch products (to be used when backend is running)
async function fetchProducts() {
    const token = localStorage.getItem('admin_token');
    try {
        const res = await fetch(`${API_BASE}/products`, {
            headers: { 'Authorization': `Bearer ${token}` }
        });
        const products = await res.json();
        // Render products into the table...
    } catch (err) {
        console.error('Failed to fetch products', err);
    }
}
