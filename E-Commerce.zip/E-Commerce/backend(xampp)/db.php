<?php
$host = 'localhost';
$user = 'root';
$pass = ''; // Default XAMPP password is empty
$db_name = 'izzyexpress';

$conn = new mysqli($host, $user, $pass);

if ($conn->connect_error) {
    die(json_encode(["error" => "Database connection failed: " . $conn->connect_error]));
}

// Select the database if it exists (setup.php will create it if not)
$conn->select_db($db_name);
?>
