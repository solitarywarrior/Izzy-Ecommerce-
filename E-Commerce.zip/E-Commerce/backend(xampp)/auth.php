<?php
session_start();
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

require 'db.php';

$data = json_decode(file_get_contents("php://input"));
$action = isset($_GET['action']) ? $_GET['action'] : '';

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

if ($action == 'login') {
    if (!empty($data->email) && !empty($data->password)) {
        $email = $conn->real_escape_string($data->email);
        $result = $conn->query("SELECT * FROM users WHERE email = '$email'");
        
        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            if (password_verify($data->password, $user['password'])) {
                
                // Set session or return a mock token
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['role'] = $user['role'];
                
                // For a completely stateless JS frontend (like React/Vanilla), returning a basic token/identifier works best.
                $token = base64_encode(json_encode(['id' => $user['id'], 'role' => $user['role'], 'time' => time()]));

                http_response_code(200);
                echo json_encode([
                    "message" => "Login successful",
                    "token" => $token,
                    "user" => [
                        "id" => $user['id'],
                        "email" => $user['email'],
                        "role" => $user['role']
                    ]
                ]);
            } else {
                http_response_code(401);
                echo json_encode(["error" => "Invalid credentials"]);
            }
        } else {
            http_response_code(401);
            echo json_encode(["error" => "Invalid credentials"]);
        }
    } else {
        http_response_code(400);
        echo json_encode(["error" => "Incomplete data"]);
    }
} 
elseif ($action == 'register') {
    if (!empty($data->email) && !empty($data->password) && !empty($data->firstName) && !empty($data->lastName)) {
        $email = $conn->real_escape_string($data->email);
        $check = $conn->query("SELECT id FROM users WHERE email = '$email'");
        if ($check->num_rows > 0) {
            http_response_code(400);
            echo json_encode(["error" => "Email already exists"]);
            exit();
        }

        $fname = $conn->real_escape_string($data->firstName);
        $lname = $conn->real_escape_string($data->lastName);
        $pass = password_hash($data->password, PASSWORD_BCRYPT);
        
        $sql = "INSERT INTO users (first_name, last_name, email, password) VALUES ('$fname', '$lname', '$email', '$pass')";
        if ($conn->query($sql) === TRUE) {
            http_response_code(201);
            echo json_encode(["message" => "User registered successfully."]);
        } else {
            http_response_code(500);
            echo json_encode(["error" => "Unable to register user."]);
        }
    } else {
        http_response_code(400);
        echo json_encode(["error" => "Incomplete data"]);
    }
} else {
    http_response_code(400);
    echo json_encode(["error" => "Invalid action"]);
}

$conn->close();
?>
