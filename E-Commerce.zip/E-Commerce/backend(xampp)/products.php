<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, DELETE, PUT, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

require 'db.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method == 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Simple Helper to check "Token" (In production, use real JWT validation)
function isAdmin() {
    $headers = apache_request_headers();
    if (isset($headers['Authorization'])) {
        $token = str_replace('Bearer ', '', $headers['Authorization']);
        $decoded = json_decode(base64_decode($token), true);
        if ($decoded && isset($decoded['role']) && $decoded['role'] === 'admin') {
            return true;
        }
    }
    return false;
}

if ($method == 'GET') {
    // Get all products
    $result = $conn->query("SELECT * FROM products ORDER BY id DESC");
    $products = [];
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            // Cast numeric strings to numbers for JS compatibility
            $row['price'] = (float)$row['price'];
            $row['trending'] = (bool)$row['trending'];
            $products[] = $row;
        }
    }
    echo json_encode($products);
} 
elseif ($method == 'POST') {
    // Create Product (Admin Only)
    if (!isAdmin()) {
        http_response_code(403);
        echo json_encode(["error" => "Admin access required"]);
        exit();
    }
    
    $data = json_decode(file_get_contents("php://input"));
    if (!empty($data->name) && !empty($data->price) && !empty($data->category)) {
        $name = $conn->real_escape_string($data->name);
        $price = (float)$data->price;
        $cat = $conn->real_escape_string($data->category);
        
        $sql = "INSERT INTO products (name, price, category) VALUES ('$name', $price, '$cat')";
        if ($conn->query($sql) === TRUE) {
            http_response_code(201);
            echo json_encode(["message" => "Product created", "id" => $conn->insert_id]);
        } else {
            http_response_code(500);
            echo json_encode(["error" => "Database error"]);
        }
    } else {
        http_response_code(400);
        echo json_encode(["error" => "Incomplete data"]);
    }
}
elseif ($method == 'DELETE') {
    // Delete Product (Admin Only)
    if (!isAdmin()) {
        http_response_code(403);
        echo json_encode(["error" => "Admin access required"]);
        exit();
    }
    
    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    if ($id > 0) {
        if ($conn->query("DELETE FROM products WHERE id = $id") === TRUE) {
            echo json_encode(["message" => "Product deleted"]);
        } else {
            http_response_code(500);
            echo json_encode(["error" => "Database error"]);
        }
    } else {
        http_response_code(400);
        echo json_encode(["error" => "Missing ID"]);
    }
} else {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
}

$conn->close();
?>
